export const environment = {
    webSocketUrl: '',

    cognitoIdentityPoolRegion: '',

    cognitoIdentityPoolId: '',

    completedCallsMergedAudioS3Bucket: '',

    activeCallsCompletedCallsMetaDataTable: '',

    completedCallsTranscriptionDataTable: '',

    preRecordedCallDetailsTable: '',

    preRecordedTranscriptionDataTable: '',

    preRecordedCallsS3Bucket: '',

    preRecordedCallsS3BucketPath: '',

    production: false
}