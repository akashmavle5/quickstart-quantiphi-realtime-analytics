import { Injectable } from '@angular/core'
import * as AWS from 'aws-sdk';
import {environment} from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AwsService {
  docClient: any
  constructor () {}

  /**
   * @desc: Function is defined to authenticate application in cognito to use aws services
   */
  authenticateUserPool () {
    AWS.config.update({
      region: environment.cognitoIdentityPoolRegion, // Region
      credentials: new AWS.CognitoIdentityCredentials({
        IdentityPoolId: environment.cognitoIdentityPoolId
      })
    })
    this.docClient = new AWS.DynamoDB.DocumentClient()
  }

  /**
   * @desc: Function is defined to get all the audios present in s3 by querying dynamodb
   * @return: Promise
   */
  getAllAudio () {
    this.authenticateUserPool()
    const table = environment.preRecordedCallDetailsTable
    const params = {
      TableName: table
    }
    return new Promise((resolve, reject) => {
      this.docClient.scan(params, function (err, data) {
        if (err) {
          console.error(
            'Unable to read item. Error JSON:',
            JSON.stringify(err, null, 2)
          )
          reject(err)
        } else {
          resolve(data)
        }
      })
    })
  }

  /**
   * @desc: Function is defined to get transcription data using filter
   * @param: Filtervalue
   * @return: Promise
   */
  getTranscribeDataByFilter (Filtervalue) {
    this.authenticateUserPool()
    const table = environment.preRecordedTranscriptionDataTable
    const filterByValue = Filtervalue
    const params = {
      TableName: table,
      FilterExpression: 'RecordedCallId = :a',
      ExpressionAttributeValues: {
        ':a': Filtervalue
      }
    }
    return new Promise((resolve, reject) => {
      this.docClient.scan(params, function (err, data) {
        if (err) {
          console.error(
            'Unable to read item. Error JSON:',
            JSON.stringify(err, null, 2)
          )
          reject(err)
        } else {
          resolve(data)
        }
      })
    })
  }

  /**
   * @desc: Function is defined to get the signed URL of the object.
   * @param data : Object
   */
  async getSignedUrl (bucketName, objectPath): Promise<any> {
    this.authenticateUserPool()
    const s3 = new AWS.S3()
    // const bucketName = 'dev-aws-chime-poc-ml'
    const params = {
      Bucket: bucketName,
      Key: objectPath,
      Expires: 60
    }
    const url = await new Promise((resolve, reject) => {
      s3.getSignedUrl('getObject', params, (err, url) => {
        err ? reject(err) : resolve(url)
      })
    })
    return url
  }

  /**
   * @desc: Function is defined to get the calls with the specified status
   * @param Filtervalue : String
   */
  getAllCallsMetaDataByFilter (Filtervalue) {
    this.authenticateUserPool()
    const table = environment.activeCallsCompletedCallsMetaDataTable
    const filterByValue = Filtervalue
    const params = {
      TableName: table,
      FilterExpression: 'StreamingStatus = :a',
      ExpressionAttributeValues: {
        ':a': Filtervalue
      }
    }
    return new Promise((resolve, reject) => {
      this.docClient.scan(params, function (err, data) {
        if (err) {
          console.error(
            'Unable to read item. Error JSON:',
            JSON.stringify(err, null, 2)
          )
          reject(err)
        } else {
          resolve(data)
        }
      })
    })
  }
  /**
   * @desc: Function is defined to get the call data based on the transactionId
   * @param filterValue : string
   */
  getCompletedCallDataByFilter (filterValue) {
    this.authenticateUserPool()
    const table = environment.completedCallsTranscriptionDataTable
    const filterByValue = filterValue
    const params = {
      TableName: table,
      FilterExpression: 'TransactionId = :a',
      ExpressionAttributeValues: {
        ':a': filterValue
      }
    }
    return new Promise((resolve, reject) => {
      this.docClient.scan(params, function (err, data) {
        if (err) {
          console.error(
            'Unable to read item. Error JSON:',
            JSON.stringify(err, null, 2)
          )
          reject(err)
        } else {
          resolve(data)
        }
      })
    })
  }

  /**
   * Returns the identification metadata from the DB for the active/completed call based on their transaction id.
   * @param filterValue : TransactionId of the call
   */
  getEntityDataByFilter (filterValue) {
    this.authenticateUserPool()
    const table = environment.activeCallsCompletedCallsMetaDataTable
    const filterByValue = filterValue
    const params = {
      TableName: table,
      FilterExpression: 'TransactionId = :a',
      ExpressionAttributeValues: {
        ':a': filterValue
      }
    }
    return new Promise((resolve, reject) => {
      this.docClient.scan(params, function (err, data) {
        if (err) {
          console.error(
            'Unable to read item. Error JSON:',
            JSON.stringify(err, null, 2)
          )
          reject(err)
        } else {
          resolve(data)
        }
      })
    })
  }

  /**
   * Returns the identification metadata from the DB for the pre recorded calls based on their call id.
   * @param filterValue : Recorded Call Id.
   */
  getEntityDataForPreRecordedByFilter (filterValue) {
    this.authenticateUserPool()
    const table = environment.preRecordedCallDetailsTable
    const filterByValue = filterValue
    const params = {
      TableName: table,
      FilterExpression: 'RecordedCallId = :a',
      ExpressionAttributeValues: {
        ':a': filterValue
      }
    }
    return new Promise((resolve, reject) => {
      this.docClient.scan(params, function (err, data) {
        if (err) {
          console.error(
            'Unable to read item. Error JSON:',
            JSON.stringify(err, null, 2)
          )
          reject(err)
        } else {
          resolve(data)
        }
      })
    })
  }
}
