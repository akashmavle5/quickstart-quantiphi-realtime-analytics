import { TestBed } from '@angular/core/testing';

import { ActiveCallsService } from './active-calls.service';

describe('ActiveCallsService', () => {
  let service: ActiveCallsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ActiveCallsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
