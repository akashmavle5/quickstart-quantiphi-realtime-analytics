import { Injectable } from '@angular/core'

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  constructor () {}

  /**
   * Sorts the data based on the Serial number
   * @param transcriptionData Array of all the transcriptions for the selected call fetched from the db.
   */
  sortTranscriptionArray (transcriptionData) {
    const sortedTranscriptionData = transcriptionData.sort((a, b) => {
      return a['SerialNo'] - b['SerialNo']
    })
    return sortedTranscriptionData
  }

  /**
   * Returns the time in mm:ss format.
   * @param time The time that is to be shortened.
   */
  getShortenedTimeFormat (time: string): string {
    try{
    const timeArray = time.split(':')
    if (timeArray.length == 3) {
      return `${timeArray[1]}:${timeArray[2]}`
    } else {
      return `${timeArray[0]}:${timeArray[1]}`
    }
  }
  catch(e)
  {
    let seconds = parseInt(time)
    let mm = Math.floor(seconds/60)
    let ss = seconds %60
    return `${mm}:${String(ss).padStart(2, '0')}`
  }
  }
  /**
   * Returns the time after converting it from hh:mm:ss || mm:ss to seconds.
   * @param time The time which has to be converted to sesonds.
   */
  getTimeInSeconds (time: string): number {
    //console.log("time",time)
    try{
    let  timeArray = time.split(':')
    let timeInSec
    if (timeArray.length == 3) {
      timeInSec = parseInt(timeArray[1]) * 60 + parseInt(timeArray[2])
    } else {
      timeInSec = parseInt(timeArray[0]) * 60 + parseInt(timeArray[1])
    }
    return timeInSec
  }
  catch(e){
    let timeInSec = parseInt(time)
    return timeInSec
  }
  }

  /**
   * @desc: Function is defined to return keywords data from the transcription data
   * @param transcriptionData : Complete transcription data
   * @return : Filter keyword data from transcription data
   */
  filterKeywordsDataFromTranscription (transcriptionData) {
    return transcriptionData.filter(ele => {
      if (
        ele['KeywordPresence'] &&
        (ele['KeywordPresence'] === 'True' || ele['KeywordPresence'] === true)
      ) {
        return ele
      } else if (ele['is_keyword']) {
        return ele
      }
    })
  }

  /**
   * @desc: Function is defined to count keyword summary data
   * @param transcriptionData : transcription data of keywords
   * @return : Returns summary data of keywords
   */
  getSummaryData (transcriptionData, callType) {
    let summaryData = []
    transcriptionData.forEach(element => {
      (callType ? element['Keywords'][0]: element['Keywords']).forEach(ele => {
        const res = {}
        const comparingKeyword = callType ? ele : ele;
        const elementFound = summaryData.find(o =>
           o['Keyword'] === comparingKeyword
        )
        const index = summaryData.indexOf(elementFound)
        if (elementFound && index) {
          summaryData[index]['Count'] = summaryData[index]['Count'] + 1
          summaryData[index]['By Warrior'] =
            element['Speaker'] === 'spk_0'
              ? summaryData[index]['By Warrior'] + 1
              : summaryData[index]['By Warrior']
          summaryData[index]['By Member'] =
            element['Speaker'] === 'spk_1'
              ? summaryData[index]['By Member'] + 1
              : summaryData[index]['By Member']
        } else {
          res['Keyword'] = callType ? ele : ele
          res['Count'] = 1
          res['By Warrior'] = element['Speaker'] === 'spk_0' ? 1 : 0
          res['By Member'] = element['Speaker'] === 'spk_1' ? 1 : 0
          summaryData.push(res)
        }
      })
    })
    return summaryData
  }
  /**
   * @desc: Function is defined to count process the transcription data from the Database.
   * @param transcriptionDataArray : The transcription data obtained from the Database connection.
   * @return : Returns the transcription data in the structure in which the UI requries.
   */
  setObjectStructureOfCompletedCallTranscriptionData (transcriptionDataArray) {
    let structuredTranscriptionData = []
    if (transcriptionDataArray) {
      for (let i = 0; i < transcriptionDataArray.length; i++) {
        let transcriptionObject = {
          text: transcriptionDataArray[i]['Transcript'],
          startTime: transcriptionDataArray[i]['StartTime'],
          endTime: transcriptionDataArray[i]['EndTime'],
          user: {
            id: this.getUserId(transcriptionDataArray[i]['Speaker'])
          }
        }
        structuredTranscriptionData = [
          ...structuredTranscriptionData,
          transcriptionObject
        ]
      }
    }
    return structuredTranscriptionData
  }

  /**
   * @desc: Function is defined to sort all the tabular data based on latest date and time
   * @param tableData : TableData array
   * @return: Function returns sorted data back to the component.
   */
  sortTableDataInActiveCalls(tableData) {
    let sortedTableData;
    try{
       sortedTableData = tableData.sort((a, b) => b.Date.localeCompare(a.Date) || b.CallStartTime.localeCompare(a.CallStartTime));
    }
    catch(e){
      console.log("sorting table data-error:",e)
      sortedTableData=tableData;
    }
    return sortedTableData;
  }

  /**
   * @desc: Function is defined to sort dropdown in pre-recorded call alphabetically
   * @param dropDownData : DropDown Data
   * @return: Function returns sorted dropdown data in alphabetically order
   */
  sortDropDownDataInPreRecordedCalls(dropDownData) {
    const sortedDropDownData = dropDownData.sort((a, b) => a.Filename.split('.')[0].localeCompare(b.Filename.split('.')[0]));
    return sortedDropDownData;
  }
  /**
   * @desc: Function is defined to map the speaker to a speaker Id
   * @param speaker : the speaker who's id is to be provided
   * @return : Returns id of the speaker.
   */
  getUserId (speaker: string): number {
    switch (speaker) {
      case 'spk_0':
        return 2
      case 'spk_1':
        return 1
      default:
        break
    }
  }
}
