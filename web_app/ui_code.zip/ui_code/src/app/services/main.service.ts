import { Injectable } from '@angular/core'
import { Observable, Subject } from 'rxjs'
import { Router } from '@angular/router'

@Injectable({
  providedIn: 'root'
})
export class MainService {
  isTranscriptionOn = new Subject<string>()
  audioSelection = new Subject<string>()
  dataTransmissionBetweenComponents = new Subject<any>()
  loadingPipeline = new Subject<any>()
  transcriptionDataPipeline = new Subject<any>()
  wavesurferTimeIntervalFromCapture = new Subject<any>()
  modalPipeline = new Subject<any>()
  activeCallsPipeline = new Subject<any>()
  activeCallsCompletedCallsPipeline = new Subject<any>()
  identificationPipeline = new Subject<any>()
  //object is defined for the api call data will be updating when APIs are integrated
  completeStateData: Object = {
    status: '',
    currentTime: '',
    fileName: ''
  }
  responseData: any
  constructor (private router: Router) {}

  /**
   * @desc: function is define do set the transcription status
   * @param status : String value to set the status
   */
  setTranscriptionStatus = (status: string) => {
    this.isTranscriptionOn.next(status)
  }

  /**
   * @desc: Function is defined to return observable and its transcription status
   * @return: Observable
   */
  getTranscriptionStatus = (): Observable<string> => {
    return this.isTranscriptionOn.asObservable()
  }

  /**
   * @desc: function is define do set the audioUrl of the current file being played.
   * @param audioUrl : String value to set the audio url.
   */
  setAudioSelection = (audioUrl: string) => {
    this.audioSelection.next(audioUrl)
  }
  /**
   * @desc: Function is defined to get audio url from pre-recorded-call component to recording component
   * @return: Observable
   */
  getaudioSelection = (): Observable<string> => {
    return this.audioSelection.asObservable()
  }
  /**
   * @desc: function is defined to set the the status and the currentTime on which the wavesurfer component is playing.
   * @param data : Object to set transcription status or the current time.
   */
  setDataTransmissionBetweenComponents = data => {
    this.completeStateData = { ...this.completeStateData, ...data }
    this.dataTransmissionBetweenComponents.next(this.completeStateData)
  }

  /**
   * @desc: Function is defined to return observable and the status of the recording component and the currentTime on which the wavesurfer component is playing.
   * @return: Observable
   */
  getDataTransmissionBetweenComponents = (): Observable<Object> => {
    return this.dataTransmissionBetweenComponents.asObservable()
  }

  /**
   * @desc: function is define do set loading value
   * @param isLoading : Boolean value to set loading true or false
   */
  setLoading (isLoading) {
    this.loadingPipeline.next(isLoading)
  }

  /**
   * @desc: Function is defined to get loading data in the form of observable
   * @return: Observable
   */
  getLoading = (): Observable<Boolean> => {
    return this.loadingPipeline.asObservable()
  }

  /**
   * @desc : function is define do set the transcription data for the pre recorded calls for the selected call.
   * @param transcriptionData : Transcription Data which is being passed to other components
   */
  setTranscriptionData = transcriptionData => {
    this.transcriptionDataPipeline.next(transcriptionData)
  }

  /**
   * @desc: Function is defined to return observable and its transcription data
   * @return: Observable
   */
  getTransctionData = (): Observable<Array<any>> => {
    return this.transcriptionDataPipeline.asObservable()
  }

  /**
   * @desc: Function is defined to set the transcription data for the pre recorded calls to the observable
   * @param responseData
   */
  setResponseData (responseData) {
    this.responseData = responseData
  }

  /**
   * @desc: Function is defined to get the transcription data for the pre recorded calls for the selected call.
   * @return: Observable
   */
  getResponseData () {
    return this.responseData
  }
  /**
   * @desc: Function is defined to set time interval from recording component to pre-recorded-call component
   * @param timeInterval : numeric value to set time interval
   */
  setwavesurferTimeIntervalFromCapture = (timeInterval: number) => {
    this.wavesurferTimeIntervalFromCapture.next(timeInterval)
  }

  /**
   * @desc: Function is defined to get time interval from pre-recorded-call component to recording component
   * @return: Observable
   */
  getwavesurferTimeIntervalFromCapture = (): Observable<number> => {
    return this.wavesurferTimeIntervalFromCapture.asObservable()
  }
  /**
   * @desc: Function is defined to set the modal data required for transcription and keyword summary download.
   * @param modalData : Object
   */
  setModalPipeline = modalData => {
    this.modalPipeline.next(modalData)
  }

  /**
   * @desc: Function is defined to return observable and the modal data required to download the transcription and keyword summary.
   * @return: Observable
   */
  getModalPipeline = (): Observable<Object> => {
    return this.modalPipeline.asObservable()
  }

  /**
   * @desc: Function is defined to set the type of active call and whether to display the table or not.
   * @param callData : Object
   */
  setActiveCallPipeline = callData => {
    this.activeCallsPipeline.next(callData)
  }

  /**
   * @desc: Function is defined to return observable and the call Type data and whether to display the table or not.
   * @return: Observable
   */
  getActiveCallPipeline = (): Observable<any> => {
    return this.activeCallsPipeline.asObservable()
  }
  /**
   * @desc: Function is defined to set the transcription data for the particular transaction id.
   * @param transcriptionData : Array of transcription for the transactionId.
   */
  setActiveCallsCompletedCallsPipeline = transcriptionData => {
    this.activeCallsCompletedCallsPipeline.next(transcriptionData)
    console.log("setActiveCallsCompletedCallsPipeline -174",transcriptionData)
  }

  /**
   * @desc: Function is defined to return observable and its transcription data
   * @return: Observable
   */
  getActiveCallsCompletedCallsPipeline = () => {
    return this.activeCallsCompletedCallsPipeline.asObservable()
  }

  /**
   * @desc : Sets the identification metadata
   * @param identificationData : identification metdata
   */
  setIdentificationData = identificationData => {
    this.identificationPipeline.next(identificationData)
  }

  /**
   * @desc : Returns the identification metadata
   * @returns {Observable}
   */
  getIdentificationData = (): Observable<any> => {
    return this.identificationPipeline.asObservable()
  }

  /**
   * @desc : Returns true if the user is on active calls/completed calls dashboard and false if the user is on pre recorded calls dashboard.
   * @returns {Boolean}
   */
  checkUrlComponent () {
    const href = this.router.url
    return href.split('/')[1] === 'calls' ? true : false
  }
}
