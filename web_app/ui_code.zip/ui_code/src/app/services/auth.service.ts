import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from './../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private router : Router,private http: HttpClient) { }

 /**
   * @desc: Function is defined for user to login
   * @param username: string email value
   * @param password: string password value
   * @return: Observable
   */
  // public loginMe=(username,password)=>{

  //   let data = {
  //     "username": username,
  //     "password": password
  // }
  //  return this.http.post(environment.loginUrl,data).toPromise();
  // }

   /**
   * @desc: Function is defined to trigger lambda function to merge s3 audio files
   * @param transactionId: string transactionId of conversation
   * @return: Observable
   */
//   public mergeAudioFiles=(transactionId)=>{
// console.log("transactionId",transactionId)
//     let data = {
//       "transactionId": transactionId
//     }
//     return this.http.post(environment.s3FilesMergeLambdaTriggerURL,data).toPromise()
//   }

 /**
   * @desc: Function is defined to set login status
   * @param status: boolean value
   */
  public setLoginStatus=(status:boolean)=>{
    status?sessionStorage.setItem('status','loggedIn****'):sessionStorage.removeItem('status')
     }

 /**
   * @desc: Function is defined to get login status
   * @return: boolean
   */
  public getLoginStatus=()=>{
    let status = false;
    try{
    status=sessionStorage.getItem('status')==='loggedIn****'
    }catch(e){
     console.log(e);
    }
    return status;
     }




}


