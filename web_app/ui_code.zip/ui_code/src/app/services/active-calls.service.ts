import { Injectable } from '@angular/core'
import { Observable, Subject } from 'rxjs'
import { environment } from '../../environments/environment'

@Injectable({
  providedIn: 'root'
})
export class ActiveCallsService {
  url: string
  ws: any
  messageSub = new Subject()
  messageSub$ = this.messageSub.asObservable()
  constructor () {
    this.url = environment.webSocketUrl
    this.setupSocketConnection()
  }
  /**
   * @desc : Function to create a socket connection
   */
  setupSocketConnection = () => {
    this.ws = new WebSocket(this.url)
    this.ws.onopen = this.onopen
    this.ws.onclose = this.onclose
    this.ws.onmessage = this.onmessage
    this.ws.onerror = this.onerror
    this.socketKeepAlive()
  }
  /**
   * @desc : Function to make dummy calls to the server to keep the socket connection alive
   */
  socketKeepAlive = () => {
    if (this.ws.readyState == this.ws.OPEN) {
      this.ws.send(
        JSON.stringify({
          service: '$default',
          transactionId: 'dummy'
        })
      )
    }
    setInterval(this.socketKeepAlive, 1000 * 60 * 5)
  }

  /**
   * @desc Callback function for the socket to perform action when the socket connection is established.
   */
  onopen = event => {
    console.log('[open] Connection established', event)
  }

  /**
   * @desc: Function is defined to send transaction ID to the backend
   * @param data : Object
   */
  sendMessage = data => {
    this.ws.send(
      JSON.stringify({
        service: 'transcribe',
        transactionId: data.TransactionId
      })
    )
  }
  /**
   * @desc Callback function for the socket to perform action when a message is received via the socket connection.
   */
  onmessage = event => {
    //console.log(`[message] Data received from server: ${event.data}`)
    if (
      (typeof event.data == 'string' &&
        (event.data.includes('transaction_id') ||
          event.data.includes('transactionId'))) ||
      event.data.includes('TransactionId') 
    ) {
      const data = JSON.parse(event.data)
      this.messageSub.next(data)
    } else if(event.data.includes('deleted files from s3 and records from tables') || event.data.includes('Internal server error')) {
      this.messageSub.next(event.data);
    }

  }
  /**
   * @desc Callback function for the socket to perform action when the socket connection is closed.
   */
  onclose = event => {
    if (event.wasClean) {
      console.log(
        `[close] Connection closed cleanly, code=${event.code} reason=${event.reason}`
      )
    } else {
      console.log('[close] Connection died')
    }
  }
  /**
   * @desc Callback function for the socket to perform action when an error occurs.
   */
  onerror = error => {
    console.log(`[error] ${error.message}`)
  }
  /**
   * @desc getter for the message subscription
   */
  getMessage () {
    return this.messageSub$
  }

  /**
   * @desc: Function is defined to delete the row from completed call table
   * @param eventData 
   */
  deleteCompletedCalls(eventData) {
    if (this.ws.readyState == this.ws.OPEN) {
      this.ws.send(
        JSON.stringify({
          service: 'delete',
          transactionId: eventData['TransactionId']
        })
      )
    }
  }

    /**
   * @desc: Function is defined to delete the row from completed call table
   * @param eventData 
   */
  mergeS3BucketFiles(eventData) {
    if (this.ws.readyState == this.ws.OPEN) {
      this.ws.send(
        JSON.stringify({
          service: 'audioMerge',
          transactionId: eventData['TransactionId']
        })
      )
    }
  }

}
