import { TestBed } from '@angular/core/testing';

import { KeywordSummaryService } from './keyword-summary.service';

describe('KeywordSummaryService', () => {
  let service: KeywordSummaryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(KeywordSummaryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
