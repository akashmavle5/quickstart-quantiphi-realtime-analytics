import {
  Component,
  OnInit,
  ChangeDetectorRef,
  AfterViewInit,
  ChangeDetectionStrategy
} from '@angular/core'
import { MainService } from 'src/app/services/main.service'
import { SharedService } from 'src/app/services/shared.service'
import { ActiveCallsService } from 'src/app/services/active-calls.service'
import { Subscription } from 'rxjs'

@Component({
  selector: 'app-keywords-capture',
  templateUrl: './keywords-capture.component.html',
  styleUrls: ['./keywords-capture.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class KeywordsCaptureComponent implements OnInit {
  keywordsArray: any = []
  globalData: any
  globalDataCopy: any
  count: number
  realTimeMessagesObservableSubscription: Subscription
  constructor (
    private ref: ChangeDetectorRef,
    private mainService: MainService,
    private sharedService: SharedService,
    private activeCallsService: ActiveCallsService
  ) {}

  ngOnInit (): void {
    this.loadKeywordComponent()
  }

  /**
   * @desc: function is defined to capture the transcription data via observable
   */
  loadKeywordComponent () {
    this.getTranscriptionDataKeywordObservableSubscription()
    this.getRealTimeMessagesKeywordObservableSubscription()
    this.getCompletedCallKeywordObservableSubscription()
  }

  /**
   * @desc: Function is defined to subscribe the transcription data observable
   */
  getTranscriptionDataKeywordObservableSubscription () {
    this.mainService.getTransctionData().subscribe(transcriptionData => {
      console.log("transcription data",transcriptionData)
      if (transcriptionData['SerialNo']) {
        const globalData = this.sharedService.sortTranscriptionArray(
          transcriptionData
        )
        this.globalData = this.sharedService.filterKeywordsDataFromTranscription(
          globalData
        )
      } else {
        this.globalData = this.sharedService.filterKeywordsDataFromTranscription(
          transcriptionData
        )
      }
      this.globalDataCopy = this.globalData.slice(0)
      this.mainService
        .getDataTransmissionBetweenComponents()
        .subscribe(objectData => {
          const timeInterval =
            objectData['status'] === 'CANCEL' ||
            objectData['status'] === 'REDO' ||
            objectData['status'] === 'LOADED'
              ? 0
              : objectData['currentTime']
          if (
            objectData['status'] === 'CANCEL' ||
            objectData['status'] === 'REDO' ||
            objectData['status'] === 'LOADED'
          ) {
            this.keywordsArray = []
            this.globalData = this.globalDataCopy.slice(0)
            this.globalDataCopy = this.globalData.slice(0)
          }
          if (objectData['status'] !== 'FINISHED') {
            this.setKeywordsData(timeInterval)
          }
          if (objectData['status'] === 'FINISHED') {
            this.keywordsArray = []
            for (let i = 0; i < this.globalDataCopy.length; i++) {
              const newKeywordObject = {
                startTime: this.globalDataCopy[i]['StartTime'],
                endTime: this.globalDataCopy[i]['EndTime'],
                keywords: this.mainService.checkUrlComponent() ? this.globalDataCopy[i]['Keywords'][0] : this.globalDataCopy[i]['Keywords'],
                message: this.globalDataCopy[i]['Transcript']
              }
              this.keywordsArray = [...this.keywordsArray, newKeywordObject]
            }
          }
          this.detectChangesHookSubscription()
        })
    })
  }

  /**
   * @desc:  Function is defined to subscribe the completed call observable
   */
  getRealTimeMessagesKeywordObservableSubscription () {
    if (this.mainService.checkUrlComponent()) {
      this.realTimeMessagesObservableSubscription = this.activeCallsService
        .getMessage()
        .subscribe(transcriptionData => {
          if (
            transcriptionData['KeywordPresence'] &&
            transcriptionData['TransactionId'] ===
              localStorage.getItem('transactionId')
          ) {
            for (let i = 0; i < transcriptionData['Keywords'].length; i++) {
              const newKeywordObject = {
                startTime: transcriptionData['StartTime'],
                endTime: transcriptionData['EndTime'],
                keywords: transcriptionData['Keywords'][i],
                message: transcriptionData['Transcript']
              }
              if(this.keywordsArray.length > 0 && this.sharedService.getTimeInSeconds(newKeywordObject.startTime) < this.sharedService.getTimeInSeconds(this.keywordsArray[this.keywordsArray.length - 1]['startTime'])) {
              const messageArray = this.keywordsArray.filter((ele)=>{
                if(this.sharedService.getTimeInSeconds(newKeywordObject.startTime) < this.sharedService.getTimeInSeconds(ele['startTime'])) {
                  return ele;
                } 
              })
              const indexOfInsertion = this.keywordsArray.indexOf(messageArray[0]);
              this.keywordsArray.splice(indexOfInsertion, 0, newKeywordObject)
              } else {
                this.keywordsArray = [...this.keywordsArray, newKeywordObject]
              }
            }
          }
          this.detectChangesHookSubscription()
        })
    }
  }

  /**
   * @desc: Function is defined to subscribe observable and get messages data from web socket
   */
  getCompletedCallKeywordObservableSubscription () {
    this.mainService
      .getActiveCallsCompletedCallsPipeline()
      .subscribe(transcriptionData => {
        const structuredTranscriptDataArray = this.sharedService.filterKeywordsDataFromTranscription(
          transcriptionData
        )
        this.globalData = structuredTranscriptDataArray.slice(0)
        this.globalDataCopy = structuredTranscriptDataArray.slice(0)
        for (let i = 0; i < this.globalData.length; i++) {
          this.globalData[i]['Keywords'].forEach(element => {
            const newKeywordObject = {
              startTime: structuredTranscriptDataArray[i]['StartTime'],
              endTime: structuredTranscriptDataArray[i]['EndTime'],
              keywords: element,
              message: structuredTranscriptDataArray[i]['Transcript']
            }
            this.keywordsArray = [...this.keywordsArray, newKeywordObject]
          })
        }
        this.detectChangesHookSubscription()
      })
  }

  /**
   * @desc: Function is defined to subscribe detectChanges Hook
   */
  detectChangesHookSubscription () {
    this.ref.detectChanges()
  }

  /**
   * @desc: Function is defined to insert new keywords in the list as the audio moves on
   * @param timeInterval : paramter which passed the time of interval in seconds for the recording component
   */
  setKeywordsData (timeInterval) {
    for (let i = this.keywordsArray.length - 1; i >= 0; i--) {
      if (
        this.sharedService.getTimeInSeconds(this.keywordsArray[i]['endTime']) >
        timeInterval
      ) {
        let oldMessage = this.keywordsArray.pop()
        oldMessage = {
          EndTime: oldMessage.endTime,
          StartTime: oldMessage.startTime,
          Transcript: oldMessage.message,
          Keywords: this.mainService.checkUrlComponent()
            ? [oldMessage.keywords]
            : oldMessage.keywords
        }
        this.globalData = [oldMessage, ...this.globalData]
        this.detectChangesHookSubscription()
      } else {
        break
      }
    }
    if (
      this.globalData.length > 0 &&
      timeInterval >=
        this.sharedService.getTimeInSeconds(this.globalData[0]['EndTime'])
    ) {
      let keywordObject = {
        startTime: this.globalData[0]['StartTime'],
        endTime: this.globalData[0]['EndTime'],
        keywords: this.mainService.checkUrlComponent()
          ? this.globalData[0]['Keywords'][0]
          : this.globalData[0]['Keywords'],
        message: this.globalData[0]['Transcript']
      }
      this.keywordsArray = [...this.keywordsArray, keywordObject]
      this.globalData.shift()
      this.detectChangesHookSubscription()
    }
  }

  /**
   * @descL Function is defined to pass timeinterval to the recording component to play audio from the time when user clicks the keyword
   * @param timeInterval : paramter which passed the time of interval in seconds for the recording component
   */
  sendTimeInterval (timeInterval) {
    this.mainService.setwavesurferTimeIntervalFromCapture(
      this.sharedService.getTimeInSeconds(timeInterval)
    )
  }

  ngOnDestroy () {
    if (!this.mainService.checkUrlComponent()) {
      try{
      this.realTimeMessagesObservableSubscription.unsubscribe()
      }
      catch(e){
        console.log("realTimeMessagesObservableSubscription:error in unsubscribe()")
      }
    }
  }
}
