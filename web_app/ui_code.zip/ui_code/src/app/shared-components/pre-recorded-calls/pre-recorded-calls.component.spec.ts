import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreRecordedCallsComponent } from './pre-recorded-calls.component';

describe('PreRecordedCallsComponent', () => {
  let component: PreRecordedCallsComponent;
  let fixture: ComponentFixture<PreRecordedCallsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreRecordedCallsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreRecordedCallsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
