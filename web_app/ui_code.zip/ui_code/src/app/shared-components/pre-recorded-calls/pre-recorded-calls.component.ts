import { Component, OnInit } from '@angular/core'
import { MainService } from '../../services/main.service'
import { AwsService } from 'src/app/services/aws.service'
import { ToastrService } from 'ngx-toastr'
import { forkJoin } from 'rxjs'
import { SharedService } from 'src/app/services/shared.service'
import { environment } from '../../../environments/environment'

@Component({
  selector: 'app-pre-recorded-calls',
  templateUrl: './pre-recorded-calls.component.html',
  styleUrls: ['./pre-recorded-calls.component.scss']
})
export class PreRecordedCallsComponent implements OnInit {
  files: any = []
  selectFile: Object = {}
  isFileSelected: Boolean = false
  constructor (
    private mainService: MainService,
    private awsService: AwsService,
    private sharedService: SharedService,
    private toaster: ToastrService
  ) {}

  ngOnInit (): void {
    this.getAudioFilesFromDb()
  }

  /**
   * @desc: Function is defined to get audio data from DB
   */
  getAudioFilesFromDb () {
    this.awsService
      .getAllAudio()
      .then(data => {
        this.files = this.sharedService.sortDropDownDataInPreRecordedCalls(
          data['Items']
        )
      })
      .catch(err => {
        console.log(err)
      })
  }

  /**
   * @desc: Function is defined to set the selected recording for the Pipeline
   * @param event : Param passed from DOM which contains the selected Data.
   */
  fileSelected (event) {
    if (event) {
      this.selectFile = event
      this.isFileSelected = true
    } else {
      this.selectFile = undefined
      this.isFileSelected = false
    }
  }

  /**
   * @desc: Function is defined to send URL to the recording component via Observable
   */
  async playRecording () {
    this.mainService.setLoading(true)
    const url = await this.awsService.getSignedUrl(
      environment.preRecordedCallsS3Bucket,
      `${environment.preRecordedCallsS3BucketPath}${this.selectFile['Filename']}`
    )
    const requestArray = [
      this.awsService.getTranscribeDataByFilter(
        this.selectFile['RecordedCallId']
      ),
      this.awsService.getEntityDataForPreRecordedByFilter(
        this.selectFile['RecordedCallId']
      )
    ]
    forkJoin(requestArray).subscribe(responseData => {
      const transcriptionData = responseData[0]
      const identificationData = responseData[1]
      if (transcriptionData) {
        this.mainService.setAudioSelection(url)
        this.mainService.setResponseData(transcriptionData['Items'])
        this.mainService.setTranscriptionData(transcriptionData['Items'])
        this.mainService.setDataTransmissionBetweenComponents({
          fileName: this.selectFile['Filename']
        })
      }
      this.mainService.setIdentificationData(identificationData['Items'][0])
    })
  }
}
