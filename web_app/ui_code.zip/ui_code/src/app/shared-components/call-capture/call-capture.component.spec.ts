import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CallCaptureComponent } from './call-capture.component';

describe('CallCaptureComponent', () => {
  let component: CallCaptureComponent;
  let fixture: ComponentFixture<CallCaptureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CallCaptureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallCaptureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
