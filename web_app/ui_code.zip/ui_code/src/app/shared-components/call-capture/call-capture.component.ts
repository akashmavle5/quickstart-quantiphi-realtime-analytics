import { Component, OnInit, ChangeDetectorRef, Input } from '@angular/core'
import { MainService } from 'src/app/services/main.service'
import { SharedService } from 'src/app/services/shared.service'
import { ActiveCallsService } from 'src/app/services/active-calls.service'
import { Router } from '@angular/router'
interface ButtonStatus {
  text: string
  message: string
  type: string
}
@Component({
  selector: 'app-call-capture',
  templateUrl: './call-capture.component.html',
  styleUrls: ['./call-capture.component.scss']
})
export class CallCaptureComponent implements OnInit {
  @Input() currentCallType: string
  recordedFileLoaded: boolean
  transcriptionButton: ButtonStatus
  transcriptionStatus: string
  transcriptionfileName: string
  transcriptionData: Array<any> = []
  summaryDataOfKeywords: Array<any>
  showModal: Boolean
  isActiveCall: Boolean = false

  constructor (
    private mainServ: MainService,
    private ref: ChangeDetectorRef,
    private sharedService: SharedService,
    private activeCallsService: ActiveCallsService,
    private router: Router
  ) {
    this.recordedFileLoaded = false

    this.transcriptionButton = {
      text: '',
      message: '',
      type: ''
    }
    this.loadRecordedFile()
  }

  ngOnInit (): void {
    this.setTranscriptionStatus()
    this.getTranscriptionDataObservableSubscription()
    this.getActiveCallsCompletedCallsPipelineObservableSubscription()
    this.getRealTimeMessagesObservaleSubscription()
  }

  /**
   * @desc: Function is defined to set transcription status which helps to render the download and keyword summary icons
   */
  setTranscriptionStatus () {
    const href = this.router.url
    this.isActiveCall = href.split('/')[1] === 'active-calls' ? true : false
    this.transcriptionStatus =
      this.isActiveCall && this.currentCallType === 'Completed Call'
        ? 'FINISHED'
        : 'STARTED'
  }

  /**
   * @desc: Function is defined to subscribe the transcription data observable
   */
  getTranscriptionDataObservableSubscription () {
    this.mainServ.getTransctionData().subscribe(transcriptionData => {
      this.transcriptionData = transcriptionData
      this.detectChangesSubscription()
    })
  }

  /**
   * @desc: Function is defined to subscribe the completed call observable
   */
  getActiveCallsCompletedCallsPipelineObservableSubscription () {
    this.mainServ
      .getActiveCallsCompletedCallsPipeline()
      .subscribe(transcriptionData => {
        this.transcriptionData = transcriptionData
        this.ref.detectChanges()
      })
  }

  /**
   * @desc: Function is defined to subscribe observable and get messages data from web socket
   */
  getRealTimeMessagesObservaleSubscription () {
    this.activeCallsService.getMessage().subscribe(message => {
      if (
        message['streamingStatus'] &&
        message['streamingStatus'] === 'ENDED' &&
        message['transactionId'] === localStorage.getItem('transactionId')
      ) {
        this.transcriptionStatus = 'FINISHED'
      }
      if (
        message['KeywordPresence'] &&
        message['TransactionId'] === localStorage.getItem('transactionId')
      ) {
        this.transcriptionData = [...this.transcriptionData, message]
      }

      this.ref.detectChanges()
    })
  }

  /**
   * @desc: Function is defined to trigger detectChanges hook
   */
  detectChangesSubscription () {
    this.ref.detectChanges()
  }

  /**
   * @desc : Sets the recordedFileLoaded variable to loaded when the event LOADED is emitted and
   * sets the call capture button based on the different events.
   */
  loadRecordedFile = (): void => {
    this.mainServ
      .getDataTransmissionBetweenComponents()
      .subscribe(objectData => {
        this.transcriptionStatus = objectData['status']
        this.transcriptionfileName = objectData['fileName']
        switch (objectData['status']) {
          case 'LOADED':
            this.recordedFileLoaded = true
            this.transcriptionButton = {
              text: 'BEGIN',
              message: '',
              type: 'BEGIN'
            }
            break
          case 'PLAYING':
            this.transcriptionButton = {
              text: 'CANCEL',
              message: 'CALL CAPTURE IN PROGRESS',
              type: 'CANCEL'
            }
            break

          case 'CANCEL':
            this.transcriptionButton = {
              text: 'REDO',
              message: 'CALL CAPTURE COMPLETED',
              type: 'REDO'
            }
            break

          case 'REDO':
            this.transcriptionButton = {
              text: 'CANCEL',
              message: 'CALL CAPTURE IN PROGRESS',
              type: 'CANCEL'
            }
            break
          case 'FINISHED':
            this.transcriptionButton = {
              text: 'REDO',
              message: 'CALL CAPTURE COMPLETED',
              type: 'REDO'
            }
            break
          default:
            break
        }
        this.ref.detectChanges()
      })
  }
  /**
   * Returns true if the message card is to be display above the call capture header.
   * @returns {boolean}
   */
  displayMessageCard = (): boolean => {
    return (
      this.transcriptionButton['type'] === 'CANCEL' ||
      this.transcriptionButton['type'] === 'REDO'
    )
  }

  /**
   * Returns true if the recorded file is loaded and and the action button
   * besides call capture header is to be displayed.
   * @returns {boolean}
   */
  displayActionButton = (): boolean => {
    return this.recordedFileLoaded && this.transcriptionButton.type === 'REDO'
  }

  /**
   * Sets the observable in the service based on the action to be performed.
   */
  handleClick = (): void => {
    switch (this.transcriptionButton.type) {
      case 'BEGIN':
        this.mainServ.setDataTransmissionBetweenComponents({ status: 'BEGIN' })
        break
      case 'CANCEL':
        this.mainServ.setDataTransmissionBetweenComponents({ status: 'CANCEL' })
        break
      case 'REDO':
        this.mainServ.setDataTransmissionBetweenComponents({ status: 'REDO' })
        break
      default:
        break
    }
  }

  /**
   * @desc: Function is defined to get the keyword data filtered from transcription data and also to find the summary data of keywords
   */
  keywordSummaryModal () {
    const keywordCaptureData = this.sharedService.filterKeywordsDataFromTranscription(
      this.transcriptionData
    )
    const summaryData = this.sharedService.getSummaryData(
      keywordCaptureData,
      this.isActiveCall
    )
    this.mainServ.setModalPipeline({
      showModal: true,
      data: summaryData,
      filename: this.transcriptionfileName,
      title: 'Keyword Summary'
    })
  }
}
