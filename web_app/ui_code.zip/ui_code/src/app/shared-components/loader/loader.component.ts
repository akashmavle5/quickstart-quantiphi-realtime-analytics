import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { MainService } from 'src/app/services/main.service';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class LoaderComponent implements OnInit {

  isLoading: Boolean = false;
  constructor(private mainService: MainService, private ref: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.getLoadingSubscription();
  }

  /**
   * @desc: Function is defined to subscribe loading observabler
   */
  getLoadingSubscription() {
    this.mainService.getLoading().subscribe(isLoadingValue => {
      this.isLoading = isLoadingValue;
      this.ref.detectChanges()
    })
  }

}
