import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Input
} from '@angular/core'
import { ActiveCallsService } from 'src/app/services/active-calls.service'
import { MainService } from 'src/app/services/main.service'
import { AwsService } from 'src/app/services/aws.service'
import { forkJoin } from 'rxjs'
import { SharedService } from 'src/app/services/shared.service'
import { ToastrService } from 'ngx-toastr'
import { AuthService } from './../../services/auth.service';

@Component({
  selector: 'app-active-call-table',
  templateUrl: './active-call-table.component.html',
  styleUrls: ['./active-call-table.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class ActiveCallTableComponent implements OnInit {
  @Input('currentTable') currentTable
  callTypes: Array<any> = []
  selectedAttributes: any
  cardTitle: String
  globalTableData: Array<any> = []
  activeCallsGlobalData: Array<any> = []
  completedCallsGlobalData: Array<any> = []
  searchValue: any
  constructor (
    private activeCallService: ActiveCallsService,
    private authService:AuthService,
    private mainService: MainService,
    private awsService: AwsService,
    private ref: ChangeDetectorRef,
    private sharedService: SharedService,
    private toaster: ToastrService
  ) {}

  ngOnInit (): void {
    this.setDropDownValuesAndInitialCardTitle()
    this.setDropDownSelectionAttribute()
    this.getRealTimeMessagesObservable()
    this.getDataMetaDataFromDb('STARTED')
  }

  /**
   * @desc: Function is defined to set dropdown values and Initial card title
   */
  setDropDownValuesAndInitialCardTitle () {
    this.callTypes = [
      { id: 1, name: 'Active Calls' },
      { id: 2, name: 'Completed Calls' }
    ]
    this.cardTitle = 'Active Calls'
  }

  /**
   * @desc: Function is defined to set the dropdown value to active calls
   */
  setDropDownSelectionAttribute () {
    this.selectedAttributes = { id: 1, name: 'Active Calls' }
  }

  /**
   * @desc: Function is defined to subsribe to the getMessages Hooks;
   */
  getRealTimeMessagesObservable () {
    this.activeCallService.getMessage().subscribe(message => {
      if (message) {
        let newMessage = {
          FromNumber: message['fromNumber'],
          ToNumber: message['toNumber'],
          StreamingStatus: message['streamingStatus'],
          Date: message['date_'],
          TransactionId: message['transactionId']
        }
        if (
          message['streamingStatus'] &&
          message['streamingStatus'] === 'STARTED'
        ) {
          const findObject = this.activeCallsGlobalData.find(
            ele => ele.TransactionId === newMessage.TransactionId
          )
          if (!findObject) {
            this.activeCallsGlobalData = [
              newMessage,
              ...this.activeCallsGlobalData
            ]
            this.globalTableData = this.activeCallsGlobalData
          }
        } else if (
          message['streamingStatus'] &&
          message['streamingStatus'] === 'ENDED'
        ) {
          const findActiveCallArray = this.activeCallsGlobalData.filter(
            element => element.TransactionId !== newMessage.TransactionId
          )
          this.activeCallsGlobalData = findActiveCallArray
          this.completedCallsGlobalData = [
            newMessage,
            ...this.completedCallsGlobalData
          ]
          this.globalTableData = this.completedCallsGlobalData
        }
      }
      this.ref.detectChanges()
    })
  }

  /**
   * @desc: Function is defined to set the dropdown value when user moves back from the respected component
   */
  setDropDownValue () {
    if (this.currentTable && this.currentTable === 'Active Call') {
      this.selectedAttributes = { id: 1, name: 'Active Calls' }
    } else if (this.currentTable && this.currentTable === 'Completed Call') {
      this.selectedAttributes = { id: 2, name: 'Completed Calls' }
    }
  }

  /**
   * @desc: Function is defined to get the metadata of calls from the DB
   * @param callType : String value (STARTED or ENDED)
   */
  getDataMetaDataFromDb (callType) {
    this.mainService.setLoading(true)
    this.globalTableData = []
    this.awsService.getAllCallsMetaDataByFilter(callType).then(data => {
      if (data['Items'].length > 0) {
        if (callType === 'ENDED') {
          this.completedCallsGlobalData = data['Items']
          this.globalTableData = this.sharedService.sortTableDataInActiveCalls(
            this.completedCallsGlobalData
          )
        } else if (callType === 'STARTED') {
          this.activeCallsGlobalData = data['Items']
          this.globalTableData = this.sharedService.sortTableDataInActiveCalls(
            this.activeCallsGlobalData
          )
        }
      }
      this.ref.detectChanges()
      this.mainService.setLoading(false)
    })
  }

  /**
   * @desc: Function is defined to handle change detection in the dropDown
   * @param event: String = Contains the selected value
   */
  async selectorChangeHandler (event) {
    if (event.name === 'Active Calls') {
      await this.getDataMetaDataFromDb('STARTED')
      this.cardTitle = event.name
    } else {
      await this.getDataMetaDataFromDb('ENDED')
      this.cardTitle = event.name
    }
  }

  /**
   * @desc: Function is defined to handle click event of view button
   * @param eventData : Object = Passes the object of the selected row
   */
  viewHandler (eventData) {
    localStorage.setItem('transactionId', eventData.TransactionId)
    if(this.cardTitle ==='Active Calls'){
      if (this.cardTitle !== 'Active Calls') {
        this.mainService.setLoading(true)
      }
      if (eventData.StreamingStatus === 'STARTED') {
        this.activeCallService.sendMessage(eventData)
      }
      const requestArray = [
        this.awsService.getCompletedCallDataByFilter(eventData.TransactionId),
        this.awsService.getEntityDataByFilter(eventData.TransactionId)
      ]
      forkJoin(requestArray).subscribe(requestData => {
        const transcriptionData = requestData[0]
        const entityData = requestData[1]
        if (transcriptionData && transcriptionData['Items'].length > 0) {
          this.mainService.setActiveCallsCompletedCallsPipeline(
            transcriptionData['Items']
          )
          //console.log("transcription data from transcript table",transcriptionData)
          this.mainService.setTranscriptionData(transcriptionData['Items'])
        }
        if (entityData && entityData['Items']) {
          this.mainService.setIdentificationData(entityData['Items'][0])
        }
      })
      console.log("requests accomplished")
      this.mainService.setActiveCallPipeline({
        callType:
          eventData.StreamingStatus === 'STARTED' ? 'Active' : 'Completed',
        showTable: false
      })}
      else{
        localStorage.setItem('transactionId', eventData.TransactionId)
        console.log(eventData)
            if (this.cardTitle !== 'Active Calls') {
              this.mainService.setLoading(true)
            }
            if (eventData.StreamingStatus === 'STARTED') {
              this.activeCallService.sendMessage(eventData)
            }
            const requestArray = [
              this.awsService.getCompletedCallDataByFilter(eventData.TransactionId),
              this.awsService.getEntityDataByFilter(eventData.TransactionId)
            ]
            forkJoin(requestArray).subscribe(requestData => {
              const transcriptionData = requestData[0]
              const entityData = requestData[1]
              if (transcriptionData && transcriptionData['Items'].length > 0) {
                this.mainService.setActiveCallsCompletedCallsPipeline(
                  transcriptionData['Items']
                )
                //console.log("transcription data from transcript table",transcriptionData)
                this.mainService.setTranscriptionData(transcriptionData['Items'])
              }
              if (entityData && entityData['Items']) {
                this.mainService.setIdentificationData(entityData['Items'][0])
              }
            })
            console.log("requests accomplished")
            this.mainService.setActiveCallPipeline({
              callType:
                eventData.StreamingStatus === 'STARTED' ? 'Active' : 'Completed',
              showTable: false
            })
          
      }
    
    
  }

  /**
   * @desc: Function is defined to return true or false for the DOM condition to show the table
   * @return : Boolean
   */
  getShowTableCondition () {
    if (
      this.activeCallsGlobalData.length > 0 &&
      this.cardTitle === 'Active Calls'
    ) {
      return true
    } else if (
      this.completedCallsGlobalData.length > 0 &&
      this.cardTitle === 'Completed Calls'
    ) {
      return true
    } else {
      return false
    }
  }

  /**
   * @desc: Function is defined to search data from array of object
   * @param event : String = Change event data from the ngModelChange handler
   */
  onChangeEvent (event: any) {
    const filteredData = this.globalTableData.filter(obj =>
      Object.keys(obj).some(key => {
        if (key !== 'customEntities') {
          return obj[key].includes(event)
        }
      })
    )
    if (this.cardTitle === 'Active Calls') {
      this.activeCallsGlobalData = filteredData
    } else if (this.cardTitle === 'Completed Calls') {
      this.completedCallsGlobalData = filteredData
    }
  }

  deleteCall = callData => {
    this.mainService.setLoading(true);
    this.activeCallService.deleteCompletedCalls(callData);
    this.activeCallService.getMessage().subscribe(async (message : any) => {
      if(message.includes('deleted files from s3 and records from tables')) {
        await this.getDataMetaDataFromDb(this.cardTitle === 'Active Calls' ? 'STARTED' : 'ENDED')
        this.toaster.success('Successfully Deleted', 'Entry Deleted');
        this.mainService.setLoading(false);
      } else if(message.includes('Internal server error')) {
        this.toaster.error('Something went wrong', 'Error');
        this.mainService.setLoading(false);
      }
    })
  }
}
