import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveCallTableComponent } from './active-call-table.component';

describe('ActiveCallTableComponent', () => {
  let component: ActiveCallTableComponent;
  let fixture: ComponentFixture<ActiveCallTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActiveCallTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveCallTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
