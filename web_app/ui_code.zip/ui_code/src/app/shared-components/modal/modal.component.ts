import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core'
import { MainService } from 'src/app/services/main.service'
import { TranscriptService } from 'src/app/services/transcript.service'

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit {
  showModal: Boolean = false
  modalTitle: string
  globalModalData: Array<any>
  fileName: string
  constructor (
    private mainService: MainService,
    private ref: ChangeDetectorRef,
    private transcriptionService: TranscriptService
  ) {}

  ngOnInit (): void {
    this.loadModalComponent()
  }

  /**
   * @desc: Function is defined to subscribe to the modal Pipeline of Observable
   */
  loadModalComponent () {
    this.mainService.getModalPipeline().subscribe(modalData => {
      this.showModal = modalData['showModal']
      this.globalModalData = modalData['data']
      this.modalTitle = modalData['title']
      this.fileName = modalData['filename']
      this.ref.detectChanges()
    })
  }

  /**
   * @desc: Function is defined to set showModal flag to false;
   */
  hide () {
    this.showModal = false
  }

  /**
   * @desc: Function is defined to download CSV from the modal
   */
  downloadCSV () {
    this.transcriptionService.downloadFile(
      this.globalModalData,
      this.fileName,
      this.modalTitle === 'Transcription Details' ? 'Transcription' : 'Keywords'
    )
  }
}
