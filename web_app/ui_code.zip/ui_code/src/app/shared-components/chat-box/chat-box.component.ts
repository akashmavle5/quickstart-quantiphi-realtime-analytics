import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef
} from '@angular/core'
import { MainService } from 'src/app/services/main.service'
import { SharedService } from 'src/app/services/shared.service'
import { ActiveCallsService } from 'src/app/services/active-calls.service'
import { Subscription } from 'rxjs'

@Component({
  selector: 'app-chat-box',
  templateUrl: './chat-box.component.html',
  styleUrls: ['./chat-box.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class ChatBoxComponent implements OnInit {
  count: number
  username = ''
  messages: any = []
  currentUser: any
  globalTranscriptionData: any = []
  globalTranscriptionDataCopy: any = []
  realTimeMessagesObservableSubscription: Subscription
  constructor (
    private ref: ChangeDetectorRef,
    private mainService: MainService,
    private sharedService: SharedService,
    private activeCallService: ActiveCallsService
  ) {}
  ngOnInit (): void {
    this.loadChatBoxComponent()
  }

  /**
   * @desc: Function is defined to subscribe all the Observable
   */
  loadChatBoxComponent () {
    this.getTranscriptionDataObservableSubscription()
    this.getRealTimeMessagesObservableSubscription()
    this.getCompletedAndActiveCallsObservableSubscription()
    this.setCurrentUserObject()
  }

  /**
   * @desc: Function is defined to initialize user object
   */
  setCurrentUserObject () {
    this.currentUser = {
      id: '2',
      me: {
        id: 2,
        name: '2'
      }
    }
  }

  /**
   * @desc: Function is defined to subscribe the transcription data observable
   */
  getTranscriptionDataObservableSubscription () {
    this.mainService.getTransctionData().subscribe(transcriptionData => {
      if (transcriptionData[0]['SerialNo']) {
        this.globalTranscriptionDataCopy = this.sharedService
          .sortTranscriptionArray(transcriptionData)
          .slice(0)
        this.globalTranscriptionData = this.sharedService.sortTranscriptionArray(
          transcriptionData
        )
      } else {
        this.globalTranscriptionDataCopy = transcriptionData.slice(0)
        this.globalTranscriptionData = transcriptionData.slice(0)
      }

      this.mainService
        .getDataTransmissionBetweenComponents()
        .subscribe(objectData => {
          const timeInterval =
            objectData['status'] === 'CANCEL' ||
            objectData['status'] === 'REDO' ||
            objectData['status'] === 'LOADED'
              ? 0
              : objectData['currentTime']
          if (
            objectData['status'] === 'CANCEL' ||
            objectData['status'] === 'REDO' ||
            objectData['status'] === 'LOADED'
          ) {
            this.messages = []
            this.globalTranscriptionData = this.globalTranscriptionDataCopy.slice(
              0
            )
            this.globalTranscriptionDataCopy = this.globalTranscriptionData.slice(
              0
            )
            this.setResponseInMessages(timeInterval)
          }
          if (objectData['status'] !== 'FINISHED') {
            this.setResponseInMessages(timeInterval)
          }
          if (objectData['status'] === 'FINISHED') {
            const transcriptionData = this.sharedService
              .setObjectStructureOfCompletedCallTranscriptionData(
                this.globalTranscriptionDataCopy
              )
              .slice(0)
            this.messages = transcriptionData
          }
          this.ref.detectChanges()
        })
    })
  }

  /**
   * @desc:  Function is defined to subscribe the completed call observable
   */
  getRealTimeMessagesObservableSubscription () {
    if (this.mainService.checkUrlComponent()) {
      this.realTimeMessagesObservableSubscription = this.activeCallService
        .getMessage()
        .subscribe(transcriptionData => {
          console.log("transcription data from observable",transcriptionData)
          if (
            transcriptionData['Transcript'] &&
            transcriptionData['TransactionId'] ===
              localStorage.getItem('transactionId')
          ) {
            let message = {
              text: transcriptionData['Transcript'],
              startTime: transcriptionData['StartTime'],
              endTime: transcriptionData['EndTime'],
              user: {
                id: this.getUserId(transcriptionData['Speaker'])
              }
            }
            if(this.messages.length > 0 && this.sharedService.getTimeInSeconds(message.startTime) < this.sharedService.getTimeInSeconds(this.messages[this.messages.length - 1]['startTime'])) {
              const messageArray = this.messages.filter((ele)=>{
                if(this.sharedService.getTimeInSeconds(message.startTime) < this.sharedService.getTimeInSeconds(ele['startTime'])) {
                  return ele;
                } 
              })
              const indexOfInsertion = this.messages.indexOf(messageArray[0]);
              this.messages.splice(indexOfInsertion, 0, message)
            } else {
              this.messages = [...this.messages, message]
              console.log("messages",this.messages)
            }
            this.ref.detectChanges()
          }
        })
    }
  }

  /**
   * @desc: Function is defined to subscribe observable and get messages data from web socket
   */
  getCompletedAndActiveCallsObservableSubscription () {
    this.mainService
      .getActiveCallsCompletedCallsPipeline()
      .subscribe(transcriptionData => {
        const structuredTranscriptDataArray = this.sharedService.setObjectStructureOfCompletedCallTranscriptionData(
          transcriptionData
        )
        this.messages = structuredTranscriptDataArray
      })
  }

  /**
   * Returns the user id based on the speaker.
   * @param speaker The speaker of the current transcript.
   */
  getUserId (speaker: string): number {
    switch (speaker) {
      case 'spk_0':
        return 2
      case 'spk_1':
        return 1
      default:
        break
    }
  }
  /**
   * Inserts the message in the messages array to display the current transcript which is being said by the user in the audio.
   * @param playTime The current time on which the wavesurfer audio is being processed.
   */
  setResponseInMessages (playTime) {
    for (let i = this.messages.length - 1; i >= 0; i--) {
      if (
        this.sharedService.getTimeInSeconds(this.messages[i]['endTime']) >
        playTime
      ) {
        let oldMessage = this.messages.pop()
        oldMessage = {
          EndTime: oldMessage.endTime,
          StartTime: oldMessage.startTime,
          Transcript: oldMessage.text,
          Speaker: oldMessage.user.id === 1 ? 'spk_1' : 'spk_0'
        }
        this.globalTranscriptionData = [
          oldMessage,
          ...this.globalTranscriptionData
        ]
        this.ref.detectChanges()
      } else {
        break
      }
    }
    if (this.globalTranscriptionData.length > 0) {
      if (
        playTime >=
        this.sharedService.getTimeInSeconds(
          this.globalTranscriptionData[0]['EndTime']
        )
      ) {
        let newMessage = {
          text: this.globalTranscriptionData[0]['Transcript'],
          startTime: this.sharedService.getShortenedTimeFormat(
            this.globalTranscriptionData[0]['StartTime']
          ),
          endTime: this.sharedService.getShortenedTimeFormat(
            this.globalTranscriptionData[0]['EndTime']
          ),
          user: {
            id: this.getUserId(this.globalTranscriptionData[0]['Speaker'])
          }
        }
        this.messages = [...this.messages, newMessage]
        this.globalTranscriptionData.shift()
        this.ref.detectChanges()
      }
    }
  }

  ngOnDestroy () {
    if (!this.mainService.checkUrlComponent()) {
      try{
      this.realTimeMessagesObservableSubscription.unsubscribe()
      }
      catch(e)
      {
        console.log("realTimeMessagesObservableSubscription:error in unsubscribe()");
      }
    }
  }
}
