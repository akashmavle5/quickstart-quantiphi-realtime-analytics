import { Component, OnInit, ChangeDetectorRef } from '@angular/core'
import WaveSurfer from 'wavesurfer.js'
import TimelinePlugin from '../../../plugin/timeline.js'
import { MainService } from '../../services/main.service'
import { AwsService } from 'src/app/services/aws.service.js'
import { Router } from '@angular/router'
import { environment } from 'src/environments/environment.js'

@Component({
  selector: 'app-recording',
  templateUrl: './recording.component.html',
  styleUrls: ['./recording.component.scss']
})
export class RecordingComponent implements OnInit {
  wavesurfer: WaveSurfer
  recording: boolean
  isActiveCall: Boolean = false
  constructor (
    private mainServ: MainService,
    private ref: ChangeDetectorRef,
    private awsService: AwsService,
    private router: Router
  ) {
    this.recording = false
  }

  ngOnInit (): void {
    this.displayRecording()
  }
  /**
   * Will create the wavesurfer instance and load it if it has a selected call recording.
   */
  displayRecording = (): void => {
    //this.mainServ.setLoading(false)
    this.setIsActive()
    this.getAudioSelectionObservableSubscription()
    this.getTranscriptionDataBetweenComponentsObservableSubscription()
    this.getAudioFileForCompletedCallsSubscription()
  }

  setIsActive () {
    const href = this.router.url
    this.isActiveCall = href.split('/')[1] === 'calls' ? true : false
    
  }

  getAudioFileForCompletedCallsSubscription () {
    this.mainServ
      .getIdentificationData()
      .subscribe(identificationDataWithObjectName => {
        console.log("identificationDataWithObjectName",identificationDataWithObjectName)
        if (
          identificationDataWithObjectName['Filename'] &&
          this.mainServ.checkUrlComponent()
        ) {
          console.log("getting signed url")
          this.awsService
            .getSignedUrl(
              environment.completedCallsMergedAudioS3Bucket,
              identificationDataWithObjectName['Filename']
            )
            .then(audioUrl => {
              this.recording = true
              this.detectChanges()
              this.createWaveSurferInstance()
              this.loadWaveSurfer(audioUrl)
            })
        }
      })
  }

  /**
   * @desc: Function is defined to subscribe the observable
   */
  getAudioSelectionObservableSubscription () {
    if(!this.mainServ.checkUrlComponent()) {
      this.mainServ.getaudioSelection().subscribe(audioUrl => {
        if (!this.recording) {
          this.recording = true
          this.detectChanges()
          this.createWaveSurferInstance()
        }
        this.loadWaveSurfer(audioUrl)
      })
    }
  }

  /**
   * @desc: Function is defined to subscribe the transcription data observable
   */
  getTranscriptionDataBetweenComponentsObservableSubscription () {
    this.mainServ
      .getDataTransmissionBetweenComponents()
      .subscribe(dataObject => {
        switch (dataObject['status']) {
          case 'BEGIN':
            this.playToggle()
            break
          case 'CANCEL':
            this.restart()
            break
          case 'REDO':
            this.playToggle()
            break
          case 'FINISHED':
            this.restart()
            break
          default:
            break
        }
      })
  }

  /**
   * Create the instance for wavesurfer for displaying the recording module.
   */
  createWaveSurferInstance = (): void => {
    if (!this.wavesurfer) {
      this.wavesurfer = WaveSurfer.create({
        container: '#waveform',
        waveColor: 'lightgray',
        cursorColor: 'red',
        progressColor: 'grey',
        responsive: true,
        skipLength: 5,
        barWidth: 2,
        barHeight: 3,
        autoCenter: true,
        hideScrollbar: true,
        scrollParent: true,
        plugins: [
          TimelinePlugin.create({
            container: '#wave-timeline',
            primaryColor:'black',
            secondaryColor:'grey',
            primaryFontColor:'#000',
            secondaryFontColor:'#111'
          })
        ]
      })
    }
  }
  /**
   * Load the required media file in the wavesurfer instance that has been created.
   */
  loadWaveSurfer = (audioUrl): void => {
    this.wavesurfer.load(audioUrl)
    this.wavesurfer.on('ready', () => {
      this.mainServ.setDataTransmissionBetweenComponents({ status: 'LOADED' })
      this.mainServ.setLoading(false)
      this.mainServ.setDataTransmissionBetweenComponents({ status: 'LOADED' })
    })
    this.wavesurfer.on('audioprocess', () => {
      this.mainServ.setDataTransmissionBetweenComponents({
        currentTime: this.wavesurfer.getCurrentTime()
      })
    })
    this.wavesurfer.on('finish', () => {
      this.mainServ.setDataTransmissionBetweenComponents({
        status: 'FINISHED'
      })
      this.wavesurfer.seekAndCenter(1)
      this.ref.detectChanges()
    })
    this.mainServ
      .getwavesurferTimeIntervalFromCapture()
      .subscribe(timeInterval => {
        this.wavesurfer.play(timeInterval)
      })
  }
  /**
   * Toggle between playing and pausing the media file depending upon the action performed.
   */
  playToggle = (): void => {
    this.mainServ.setDataTransmissionBetweenComponents({ status: 'PLAYING' })
    this.wavesurfer.playPause()
    this.mainServ.setDataTransmissionBetweenComponents({ status: 'PLAYING' })
    this.mainServ.setDataTransmissionBetweenComponents({
      currentTime: this.wavesurfer.getCurrentTime()
    })
    this.detectChanges()
  }
  /**
   * Position the cursor back to the start to restart the playing of the audio file.
   */
  restart = (): void => {
    this.wavesurfer.stop()
    this.detectChanges()
  }
  /**
   * Skip the audio file by the (skipLength) number of seconds and forward it.
   */
  skipForward = (): void => {
    if (this.wavesurfer.getDuration() - this.wavesurfer.getCurrentTime() > 5)
      this.wavesurfer.skipForward()
  }
  /**
   * Skip the audio file by the (skipLength) number of seconds and move backward.
   */
  skipBackward = (): void => {
    this.wavesurfer.skipBackward()
  }
  /**
   * Toggle between completely muting the volume and unmuting it.
   */
  toggleMute = (): void => {
    this.wavesurfer.toggleMute()
  }
  /**
   * Toggle between displaying the play and pause button.
   * @returns {boolean} Returns true when the audio file is playing and false when it is paused.
   */
  displayPlayButton = (): boolean => {
    return this.wavesurfer ? this.wavesurfer.isPlaying() : false
  }

  /**
   * @desc : Function to jump directly to the end of the call when clicked on the end button
   */
  endCall = () => {
    if (this.wavesurfer) {
      this.mainServ.setDataTransmissionBetweenComponents({
        status: 'FINISHED',
        currentTime: this.wavesurfer.getCurrentTime()
      })
      this.wavesurfer.seekAndCenter(1)
      this.ref.detectChanges()
    }
  }

  detectChanges = () => {
    this.ref.detectChanges()
  }

  ngOnDestroy () {
    if (this.wavesurfer) {
      this.wavesurfer.destroy()
    }
  }
}
