import { Component, OnInit } from '@angular/core'
import { Router, ActivatedRoute, ParamMap } from '@angular/router'
import * as $ from 'jquery'
import { AuthService } from './../../services/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  isNavBarOpen: Boolean = false
  isActiveTab: String = 'recordings'
  constructor (private router: Router,private authService:AuthService) {}

  ngOnInit (): void {
    this.getCurrentRoute()
  }
  /**
   * @desc Routes to the respective component depending upon the url.
   */
  getCurrentRoute () {
    switch (this.router.url) {
      case '/calls':
        this.isActiveTab = 'active-calls'
        break
      default:
        this.isActiveTab = 'active-calls'
        break
    }
  }

  /**
   * @desc: Function is defined to toggle the navbar
   * @param isOpen : String value which indicates whether the side navbar is opened or closed.
   */
  toggleNavbar (isOpen) {
    this.isNavBarOpen = isOpen === 'open' ? true : false
  }

  /**
   * @desc: Function is defined to route to the respective component
   * @param activeTab : String value which contains the active tab value.
   */
  navigateUrl (activeTab) {
    this.isActiveTab = activeTab
    switch (activeTab) {
      case 'active-calls':
        this.router.navigate(['/calls'])
        break
      default:
        this.router.navigate(['/login'])
        break
    }
  }
    /**
   * @desc: Function is defined to logout user
   */
  logout () {
   this.authService.setLoginStatus(false);
   this.router.navigate(['/login']);
    }

  /**
   * @desc: Function is defined to changed the width of the side navbar from 5rem to 11.5rem. This function is used in NgStyle in DOM.
   */
  getStyleObject () {
    if (this.isNavBarOpen) {
      return { width: '11.5rem', transition: '0.5s' }
    } else {
      return { width: '5rem', transition: '0.5s' }
    }
  }
}
