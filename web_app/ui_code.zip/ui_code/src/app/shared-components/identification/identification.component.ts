import { Component, OnInit, ChangeDetectorRef } from '@angular/core'
import { MainService } from 'src/app/services/main.service'
import { ActiveCallsService } from 'src/app/services/active-calls.service'
import { Router } from '@angular/router'

@Component({
  selector: 'app-identification',
  templateUrl: './identification.component.html',
  styleUrls: ['./identification.component.scss']
})
export class IdentificationComponent implements OnInit {
  constructor (
    private mainService: MainService,
    private activeCallService: ActiveCallsService,
    private router: Router,
    private ref: ChangeDetectorRef
  ) {}

  identificationData: any
  showIdentification: Boolean = true
  isActiveCall: Boolean = false
  ngOnInit (): void {
    this.loadIdentificationComponent()
  }

  /**
   * @desc: Function is defined to load the subscription
   */
  loadIdentificationComponent () {
    this.initializeIdentification()
    this.getIdentificationObservableSubscription()
    this.getRealDataObservableSubscription()
  }

  /**
   * @desc: Function is defined initialize the object
   */
  initializeIdentification () {
    const href = this.router.url
    this.isActiveCall = href.split('/')[1] === 'calls' ? true : false
    this.identificationData = [
      {
        'Member Name': '',
        'CallBack phone no.': '',
        'Member ID number': '',
        DOB: ''
      },
      {
        'Provider Name': '',
        "Provider's Hospital/Facility Info": ''
      }
    ]
  }

  /**
   * @desc: Function is defined to subscribe identification subscription
   */
  getIdentificationObservableSubscription () {
    this.mainService.getIdentificationData().subscribe(identificationData => {
      if (identificationData && identificationData['customEntities']) {
        this.mainService
          .getDataTransmissionBetweenComponents()
          .subscribe(data => {
            if (data['status'] === 'FINISHED') {
              this.showIdentification = true
              this.identificationData = this.getIdentificationObjectData(
                identificationData
              )
              this.ref.detectChanges()
            } else {
              this.showIdentification = true
              this.identificationData = [
                {
                  'Member Name': '',
                  'CallBack phone no.': '',
                  'Member ID number': '',
                  DOB: ''
                },
                {
                  'Provider Name': '',
                  "Provider's Hospital/Facility Info": ''
                }
              ]
              this.ref.detectChanges()
            }
          })
      }
    })
  }

  /**
   * @desc: Function is defined to subscribe real time data from socket
   */
  getRealDataObservableSubscription () {
    this.activeCallService.getMessage().subscribe(messageData => {
      if (
        messageData &&
        messageData['streamingStatus'] === 'ENDED' &&
        messageData['transactionId'] === localStorage.getItem('transactionId')
      ) {
        this.identificationData = this.getIdentificationObjectData(messageData)
      }
    })
  }

  /**
   * @desc: Function is defined to structure the identification object
   * @param identificationData
   */
  getIdentificationObjectData (identificationData) {
    return [
      {
        'Member Name':
          identificationData['customEntities']['memberInfo'][0]['memberName'],
        'CallBack phone no.':
          identificationData['customEntities']['memberInfo'][0][
            'callbackPhoneNumber'
          ],
        'Member ID number':
          identificationData['customEntities']['memberInfo'][0][
            'memberIDNumber'
          ],
        DOB: identificationData['customEntities']['memberInfo'][0]['DOB']
      },
      {
        'Provider Name':
          identificationData['customEntities']['providerInfo'][0][
            'providerName'
          ],
        "Provider's Hospital/Facility Info":
          identificationData['customEntities']['providerInfo'][0][
            'providerFacility'
          ]
      }
    ]
  }
}
