import { Component, OnInit, ChangeDetectorRef, Input } from '@angular/core'
import { MainService } from 'src/app/services/main.service'
import { TranscriptService } from 'src/app/services/transcript.service'
import { SharedService } from 'src/app/services/shared.service'
import { ActiveCallsService } from 'src/app/services/active-calls.service'
import { Router } from '@angular/router'
interface ButtonStatus {
  text: string
  message: string
  type: string
}
@Component({
  selector: 'app-transcription',
  templateUrl: './transcription.component.html',
  styleUrls: ['./transcription.component.scss']
})
export class TranscriptionComponent implements OnInit {
  @Input() currentCallType: string
  recordedFileLoaded: boolean
  transcriptionButton: ButtonStatus
  transcriptionData: Array<any> = []
  transcriptionStatus: string
  transcriptionfileName: string
  isActiveCall: Boolean = false
  realTimeGetMessagesObservable: any
  constructor (
    private mainServ: MainService,
    private ref: ChangeDetectorRef,
    private transcriptServ: TranscriptService,
    private sharedService: SharedService,
    private activeCallsService: ActiveCallsService,
    private router: Router
  ) {}

  ngOnInit (): void {
    this.setTranscriptionButtonObject()
    this.setTranscriptionStatus()
    this.loadRecordedFile()
    this.loadTranscriptionComponent()
  }

  /**
   * @desc: Function is defined to set transcription button object
   */
  setTranscriptionButtonObject () {
    this.recordedFileLoaded = false
    this.transcriptionButton = {
      text: '',
      message: '',
      type: ''
    }
  }

  /**
   * @desc: Function is defined to set transcription Status
   */
  setTranscriptionStatus () {
    const href = this.router.url
    this.isActiveCall = href.split('/')[1] === 'active-calls' ? true : false
    this.transcriptionStatus =
      this.isActiveCall && this.currentCallType === 'Completed Call'
        ? 'FINISHED'
        : 'STARTED'
  }

  /**
   * @desc: Function is defined to subscribe all Observable
   */
  loadTranscriptionComponent () {
    this.getTranscriptionDataObservableSubscriptions()
    this.getActiveCallsCompletedCallsObservableSubscriptions()
    this.getRealTimeMessagesObservableSubscriptions()
  }

  /**
   * @desc: Function is defined to subscribe transcription data observable
   */
  getTranscriptionDataObservableSubscriptions () {
    this.mainServ.getTransctionData().subscribe(data => {
      this.transcriptionData = data
    })
  }

  /**
   * @desc: Function is defined to subscribe completed call observable
   */
  getActiveCallsCompletedCallsObservableSubscriptions () {
    this.mainServ
      .getActiveCallsCompletedCallsPipeline()
      .subscribe(transcriptionData => {
        this.transcriptionData = transcriptionData
      })
  }

  /**
   * @desc: Function is defined to subscribe real time message observable
   */
  getRealTimeMessagesObservableSubscriptions () {
    this.realTimeGetMessagesObservable = this.activeCallsService
      .getMessage()
      .subscribe(message => {
        if (
          message['streamingStatus'] &&
          message['streamingStatus'] === 'ENDED' &&
          message['transactionId'] === localStorage.getItem('transactionId')
        ) {
          this.transcriptionStatus = 'FINISHED'
        } else if (
          !message['CallbackPhoneNumber'] &&
          message['TransactionId'] === localStorage.getItem('transactionId')
        ) {
          this.transcriptionData = [...this.transcriptionData, message]
        }
        this.ref.detectChanges()
      })
  }

  /**
   * Sets the recordedFileLoaded variable to loaded when the event LOADED is emitted and
   * sets the transcription button based on the different events.
   */
  loadRecordedFile = (): void => {
    this.mainServ
      .getDataTransmissionBetweenComponents()
      .subscribe(objectData => {
        this.transcriptionStatus = objectData['status']
        this.transcriptionfileName = objectData['fileName']

        switch (objectData['status']) {
          case 'LOADED':
            this.recordedFileLoaded = true
            this.transcriptionButton = {
              text: 'BEGIN',
              message: '',
              type: 'BEGIN'
            }
            break
          case 'PLAYING':
            this.transcriptionButton = {
              text: 'CANCEL',
              message: 'TRANSCRIPTION IN PROGRESS',
              type: 'CANCEL'
            }
            break

          case 'CANCEL':
            this.transcriptionButton = {
              text: 'REDO',
              message: 'TRANSCRIPTION COMPLETED',
              type: 'REDO'
            }
            break

          case 'REDO':
            this.transcriptionButton = {
              text: 'CANCEL',
              message: 'TRANSCRIPTION IN PROGRESS',
              type: 'CANCEL'
            }
            break

          case 'FINISHED':
            this.transcriptionButton = {
              text: 'REDO',
              message: 'TRANSCRIPTION COMPLETED',
              type: 'REDO'
            }
            break
          default:
            break
        }
        this.ref.detectChanges()
      })
  }
  /**
   * Returns true if the message card is to be display above the transcription header.
   * @returns {boolean}
   */
  displayMessageCard = (): boolean => {
    return (
      this.transcriptionButton['type'] === 'CANCEL' ||
      this.transcriptionButton['type'] === 'REDO'
    )
  }

  /**
   * Returns true if the recorded file is loaded and and the action button
   * besides transcription header is to be displayed.
   * @returns {boolean}
   */
  displayActionButton = (): boolean => {
    return this.recordedFileLoaded && this.transcriptionButton.type != ''
  }

  /**
   * Sets the observable in the service based on the action to be performed.
   */
  handleClick = (): void => {
    switch (this.transcriptionButton.type) {
      case 'BEGIN':
        this.mainServ.setDataTransmissionBetweenComponents({ status: 'BEGIN' })
        break
      case 'CANCEL':
        this.mainServ.setDataTransmissionBetweenComponents({ status: 'CANCEL' })
        break
      case 'REDO':
        this.mainServ.setDataTransmissionBetweenComponents({ status: 'REDO' })
        break
      default:
        break
    }
  }

  /**
   * @desc: Function is defined to download data in CSV format
   */
  downloadCsv (): void {
    const transcriptionSummary = this.transcriptServ.changeSpeakerNameKeywordInTransition(
      this.isActiveCall
        ? this.transcriptionData
        : this.sharedService.sortTranscriptionArray(this.transcriptionData),
      this.isActiveCall
    )
    this.mainServ.setModalPipeline({
      showModal: true,
      data: transcriptionSummary,
      filename: this.transcriptionfileName,
      title: 'Transcription Details'
    })
  }

  ngOnDestroy () {
    if (!this.isActiveCall) {
      this.realTimeGetMessagesObservable.unsubscribe()
    }
  }
}
