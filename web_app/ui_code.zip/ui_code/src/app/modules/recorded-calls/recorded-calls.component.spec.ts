import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecordedCallsComponent } from './recorded-calls.component';

describe('RecordedCallsComponent', () => {
  let component: RecordedCallsComponent;
  let fixture: ComponentFixture<RecordedCallsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecordedCallsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecordedCallsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
