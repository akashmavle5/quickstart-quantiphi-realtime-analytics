import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recorded-calls',
  templateUrl: './recorded-calls.component.html',
  styleUrls: ['./recorded-calls.component.scss']
})
export class RecordedCallsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
