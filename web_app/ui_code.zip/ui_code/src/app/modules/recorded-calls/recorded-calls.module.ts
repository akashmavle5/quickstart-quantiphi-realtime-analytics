import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { NgSelectModule } from '@ng-select/ng-select'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { RecordedCallsRoutingModule } from './recorded-calls-routing.module'
import { RecordedCallsComponent } from './recorded-calls.component'
import { PreRecordedCallsComponent } from '../../shared-components/pre-recorded-calls/pre-recorded-calls.component'
import { ToastrModule } from 'ngx-toastr'
import { SharedModuleModule } from '../shared-module/shared-module.module'

@NgModule({
  declarations: [RecordedCallsComponent, PreRecordedCallsComponent],
  imports: [
    CommonModule,
    RecordedCallsRoutingModule,
    NgSelectModule,
    FormsModule,
    ToastrModule,
    ReactiveFormsModule,
    SharedModuleModule
  ]
})
export class RecordedCallsModule {}
