import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { AuthService } from './../../../services/auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  public password = "";
  public username = "";
  constructor(private toastr: ToastrService,private router:Router,private authService:AuthService) { }

  ngOnInit(): void {
    
  }
  public submit = () => {
    if (!this.username || !this.password) {
       this.toastr.error('Please enter email and password', 'Invalid credentials', { timeOut: 1000 });
    }
    else
    {   this.toastr.info('Checking credentials', 'Validation', { timeOut: 2000 });
    }

  }

  checkForSubmit = (e) => {
    if (e.keyCode == 13 && this.username && this.password) {
      this.submit();
    }
  }
}
