import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { DashboardRoutingModule } from './dashboard-routing.module'
import { DashboardComponent } from './dashboard.component'
import { ActiveCallModule } from '../active-call/active-call.module'
import { RecordedCallsModule } from '../recorded-calls/recorded-calls.module'
import { NavbarComponent } from 'src/app/shared-components/navbar/navbar.component'
import { LoaderComponent } from 'src/app/shared-components/loader/loader.component'
import { ToastrModule } from 'ngx-toastr'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [DashboardComponent, NavbarComponent, LoaderComponent, LoginComponent],
  imports: [
  CommonModule,
    DashboardRoutingModule,
    ActiveCallModule,
    RecordedCallsModule,
    BrowserAnimationsModule,
    FormsModule,
    ToastrModule.forRoot({
      maxOpened: 1
    })
  ]
})
export class DashboardModule {}
