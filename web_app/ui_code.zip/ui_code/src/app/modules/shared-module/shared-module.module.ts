import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { ModalComponent } from 'src/app/shared-components/modal/modal.component'
import { TranscriptionComponent } from 'src/app/shared-components/transcription/transcription.component'
import { KeywordsCaptureComponent } from 'src/app/shared-components/keywords-capture/keywords-capture.component'
import { ChatBoxComponent } from 'src/app/shared-components/chat-box/chat-box.component'
import { IdentificationComponent } from 'src/app/shared-components/identification/identification.component'
import { CallCaptureComponent } from 'src/app/shared-components/call-capture/call-capture.component'
import { RecordingComponent } from 'src/app/shared-components/recording/recording.component'

@NgModule({
  declarations: [
    ModalComponent,
    TranscriptionComponent,
    KeywordsCaptureComponent,
    ChatBoxComponent,
    IdentificationComponent,
    CallCaptureComponent,
    RecordingComponent
  ],
  imports: [CommonModule],
  exports: [
    ModalComponent,
    TranscriptionComponent,
    KeywordsCaptureComponent,
    ChatBoxComponent,
    IdentificationComponent,
    CallCaptureComponent,
    RecordingComponent
  ]
})
export class SharedModuleModule {}
