import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { ActiveCallRoutingModule } from './active-call-routing.module'
import { ActiveCallComponent } from './active-call.component'
import { SharedModuleModule } from '../shared-module/shared-module.module'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { NgSelectModule } from '@ng-select/ng-select'
import { ToastrModule } from 'ngx-toastr'
import { ActiveCallTableComponent } from 'src/app/shared-components/active-call-table/active-call-table.component'

@NgModule({
  declarations: [ActiveCallComponent, ActiveCallTableComponent],
  imports: [
    CommonModule,
    ActiveCallRoutingModule,
    SharedModuleModule,
    NgSelectModule,
    FormsModule,
    ToastrModule,
    ReactiveFormsModule
  ]
})
export class ActiveCallModule {}
