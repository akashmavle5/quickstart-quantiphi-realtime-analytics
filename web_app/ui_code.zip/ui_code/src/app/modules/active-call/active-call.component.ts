import { Component, OnInit,  ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { MainService } from 'src/app/services/main.service';

@Component({
  selector: 'app-active-call',
  templateUrl: './active-call.component.html',
  styleUrls: ['./active-call.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class ActiveCallComponent implements OnInit {

  showTable: Boolean = true;
  showRecording: Boolean = false;
  callType: String = '';
  constructor(private ref: ChangeDetectorRef, private mainService: MainService) { }

  ngOnInit(): void {
    this.getActiveCallObservableSubscription();
  }

  /**
   * @desc: Function is defined to subscribe get active call Observable
   */
  getActiveCallObservableSubscription() {
    this.mainService.getActiveCallPipeline().subscribe(activeCallData => {
      this.callType = `${activeCallData.callType} Call`
      this.showTable = activeCallData.showTable;
      this.showRecording = activeCallData.callType === 'Active' ? false : true;
      this.ref.detectChanges();
    })
  }

  /**
   * @desc: Function is defined to handle button click event of back button
   */
  backButtonHandler() {
    const confirmation = confirm(this.showRecording ? 'Are you sure you want to move back ?':'Are you sure you want to move back ? The current Live Transcription will be lost')
    this.showTable = confirmation ? true : false;
  }

}
